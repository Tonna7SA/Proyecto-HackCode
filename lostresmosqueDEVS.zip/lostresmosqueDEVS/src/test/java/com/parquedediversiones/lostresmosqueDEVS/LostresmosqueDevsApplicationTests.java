package com.parquedediversiones.lostresmosqueDEVS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostresmosqueDevsApplicationTests {

	@Test
	void contextLoads() {
	}

}
