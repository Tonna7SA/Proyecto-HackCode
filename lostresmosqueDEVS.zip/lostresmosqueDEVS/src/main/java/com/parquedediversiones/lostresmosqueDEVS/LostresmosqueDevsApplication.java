package com.parquedediversiones.lostresmosqueDEVS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LostresmosqueDevsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LostresmosqueDevsApplication.class, args);
	}

}
